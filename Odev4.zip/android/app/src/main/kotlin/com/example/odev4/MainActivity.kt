package com.example.odev4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
